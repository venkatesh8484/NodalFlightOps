// ============================================
// OntologyEngine — direct-to-provider AI client
// ============================================
// No backend, no Databricks. Every call goes straight from the browser to
// the configured provider (Gemini / OpenRouter / Claude), reusing the exact
// same aiConfig (provider/apiKey/model) the app's AI Settings modal already
// manages for the reroute agent.

export async function callProviderChat(aiConfig, systemPrompt, userPrompt, maxTokens = 16000) {
  const { provider, apiKey, model } = aiConfig || {};
  if (!apiKey) {
    throw new Error('No API key configured. Open Settings (gear icon) and add a provider API key.');
  }

  if (provider === 'gemini') {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `${systemPrompt}\n\n${userPrompt}` }] }],
          generationConfig: { temperature: 0, maxOutputTokens: maxTokens },
        }),
      }
    );
    if (!res.ok) throw new Error(`Gemini API error ${res.status}: ${await res.text()}`);
    const data = await res.json();
    const parts = data?.candidates?.[0]?.content?.parts || [];
    return parts.map((p) => p.text || '').join('');
  }

  if (provider === 'openrouter') {
    const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
        'HTTP-Referer': typeof window !== 'undefined' ? window.location.origin : 'https://flightops.local',
        'X-Title': 'FlightOps OntologyEngine',
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        temperature: 0,
        max_tokens: maxTokens,
      }),
    });
    if (!res.ok) throw new Error(`OpenRouter API error ${res.status}: ${await res.text()}`);
    const data = await res.json();
    return data?.choices?.[0]?.message?.content || '';
  }

  if (provider === 'claude') {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model,
        max_tokens: maxTokens,
        temperature: 0,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }],
      }),
    });
    if (!res.ok) throw new Error(`Claude API error ${res.status}: ${await res.text()}`);
    const data = await res.json();
    return (data?.content || []).map((c) => c.text || '').join('');
  }

  throw new Error(`Unsupported AI provider: ${provider}`);
}

function cleanJsonResponse(text) {
  let t = (text || '').trim();
  if (t.startsWith('```')) {
    t = t.replace(/^```/, '').trim();
    if (/^json/i.test(t)) t = t.slice(4).trim();
    if (t.endsWith('```')) t = t.slice(0, -3).trim();
  }
  return t;
}

function extractFirstJsonBlock(text) {
  let start = -1;
  for (let i = 0; i < text.length; i++) {
    if (text[i] === '[' || text[i] === '{') {
      start = i;
      break;
    }
  }
  if (start === -1) return null;

  const stack = [];
  let inString = false;
  let escape = false;

  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escape) escape = false;
      else if (ch === '\\') escape = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') {
      inString = true;
      continue;
    }
    if (ch === '[' || ch === '{') {
      stack.push(ch);
    } else if (ch === ']' || ch === '}') {
      if (!stack.length) return null;
      const opener = stack.pop();
      if ((opener === '[' && ch !== ']') || (opener === '{' && ch !== '}')) return null;
      if (!stack.length) return text.slice(start, i + 1);
    }
  }
  return null;
}

/**
 * Ask the configured AI provider for strict JSON. Mirrors the retry -> extract
 * -> AI-repair fallback chain the original Python pipeline used (_ask_json).
 */
export async function askJson(aiConfig, systemPrompt, userPrompt, maxTokens = 16000) {
  let lastError = null;

  for (let attempt = 0; attempt < 3; attempt++) {
    const sys =
      attempt === 0
        ? systemPrompt
        : 'Return strict, complete, valid JSON only. No prose, no code fences, no trailing fragments.';
    const usr =
      attempt === 0
        ? userPrompt
        : `${userPrompt}\n\nIMPORTANT: Output must be complete JSON (not truncated).`;

    let content;
    try {
      content = await callProviderChat(aiConfig, sys, usr, maxTokens);
    } catch (err) {
      lastError = err;
      continue;
    }

    let cleaned = cleanJsonResponse(content);
    try {
      return JSON.parse(cleaned);
    } catch (ex) {
      lastError = ex;
    }

    const extracted = extractFirstJsonBlock(cleaned);
    if (extracted) {
      try {
        return JSON.parse(extracted);
      } catch (ex) {
        cleaned = extracted;
        lastError = ex;
      }
    }

    try {
      const repaired = await callProviderChat(
        aiConfig,
        'You repair malformed JSON. Return only corrected valid JSON with no markdown. Do not add explanatory text. Preserve original data and structure.',
        `Repair this malformed JSON and return valid JSON only:\n\n${cleaned}`,
        maxTokens
      );
      const repairedClean = cleanJsonResponse(repaired);
      return JSON.parse(repairedClean);
    } catch (ex) {
      lastError = ex;
    }
  }

  throw new Error(`Unable to parse valid JSON from AI response after retries: ${lastError}`);
}
